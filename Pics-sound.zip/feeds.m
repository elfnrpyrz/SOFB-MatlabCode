function feeds(playthissound)
% This function plays a given song file. Can be used for feedbacks, that
% don't require a separate pic.

[YY, FFss] = audioread(playthissound); 
sound = audioplayer(YY, FFss);
play(sound);
pause;

end